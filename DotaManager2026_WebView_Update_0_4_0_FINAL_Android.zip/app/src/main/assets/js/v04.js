/* ===== UPDATE 0.4 ===== */
(function(){
const{rnd,pickOf,orgOf,strength}=DM;
const SET=(()=>{try{return JSON.parse(localStorage.getItem('dm26-set'))||{}}catch(e){return{}}})();SET.snd=SET.snd!==false;SET.diff=+SET.diff||0;window.DIFF=SET.diff;
const saveSet=()=>{try{localStorage.setItem('dm26-set',JSON.stringify(SET))}catch(e){}};
// ---- audio
const aud={},A=n=>aud[n]||(aud[n]=new Audio('audio/'+n+'.wav'));let bgm=null,cur='home';
function music(n){cur=n;if(!SET.snd){if(bgm)bgm.pause();return}if(bgm&&bgm._n===n){bgm.play().catch(()=>{});return}if(bgm)bgm.pause();bgm=A(n);bgm._n=n;bgm.loop=true;bgm.volume=.3;bgm.play().catch(()=>{})}
function sfx(n){if(!SET.snd)return;try{const a=A(n).cloneNode();a.volume=.6;a.play().catch(()=>{})}catch(e){}}
document.addEventListener('click',e=>{if(e.target.closest('button'))sfx('click');if(!bgm)music(cur)});
const _go=go;go=function(id){_go(id);music(id==='market'?'market':id==='events'?'match':'home')};
// ---- heroes
const HB={};HERO_DB.forEach((h,i)=>{h.i=i;HB[h.id]=h});const byRole=r=>HERO_DB.filter(h=>h.r===r);
const hash=x=>{let v=0;for(const c of String(x))v=(v*31+c.charCodeAt(0))>>>0;return v};
const pool=p=>{const L=byRole(p.role),h=hash(p.id);return[0,1,2].map(k=>L[(h+k*5+k*k)%L.length])};
const TR=['Лидер','Клатч','Хрупкий','Трудяга'],trait=p=>TR[hash(p.id+'t')%4];
const himg=h=>`<img src="heroes/${h.id}.png" width="26" height="26" style="border-radius:6px;vertical-align:middle" alt="">`;
window.eff=p=>p.skill+((p.form==null?50:p.form)-50)/8-(p.fat||0)/15-(p.inj?15:0)+(trait(p)==='Лидер'?1:0);
const cnt=(a,b)=>{const d=(a.i-b.i+60)%60;return d>=1&&d<=3?1:d>=57?-1:0};
// ---- overlay
const st=document.createElement('style');st.textContent='#ov{position:fixed;inset:0;background:#000d;z-index:50;overflow:auto;padding:12px}#ov>div{max-width:500px;margin:0 auto;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px}.fl{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.smallbtn.on{background:var(--purple)}';document.head.appendChild(st);
const ovEl=document.createElement('div');ovEl.id='ov';ovEl.hidden=true;document.body.appendChild(ovEl);let act=null;
const ov=h=>{ovEl.innerHTML='<div>'+h+'</div>';ovEl.hidden=false;ovEl.scrollTop=0},closeOv=()=>{ovEl.hidden=true;ovEl.innerHTML=''};
ovEl.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(b&&act)act(b.dataset)});
// ---- draft
function draft(eid){return new Promise(res=>{
 const team=active(),en=rosterData[eid],ep=roles.map(r=>en.players.filter(p=>p.role===r).sort((a,b)=>b.skill-a.skill)[0]).filter(Boolean).map(p=>({p,h:pool(p)[0]}));let ban=null,pk={};
 const draw=()=>ov(`<h3>🎯 Драфт vs ${en.name}</h3><div class="sub">1) Забань ключевого героя соперника. 2) Выбери героев: «комфорт» даёт бонус, контрпик тоже.</div><b class="sub">Баны:</b><div class="fl">${ep.map((x,i)=>`<button class="smallbtn ${ban===i?'on':''}" data-a="ban" data-v="${i}">${himg(x.h)} ${x.h.n}</button>`).join('')}</div>${team.map(p=>`<div class="card" style="margin-top:6px"><b>${p.role}: ${p.name}</b><div class="fl">${pool(p).map(h=>`<button class="smallbtn ${pk[p.id]===h.id?'on':''}" data-a="pk" data-p="${p.id}" data-v="${h.id}">${himg(h)} ${h.n}</button>`).join('')}<button class="smallbtn ${pk[p.id]==='x'?'on':''}" data-a="pk" data-p="${p.id}" data-v="x">🎲 Эксперимент</button></div></div>`).join('')}<div class="fl"><button class="smallbtn" data-a="auto">⚡ Авто</button></div><button class="wide primary" data-a="go" ${team.every(p=>pk[p.id])&&ban!==null?'':'disabled'}>Подтвердить драфт</button>`);
 act=d=>{if(d.a==='ban')ban=+d.v;else if(d.a==='pk')pk[d.p]=d.v;else if(d.a==='auto'){ban=0;team.forEach(p=>pk[p.id]=pool(p)[0].id)}
  else if(d.a==='go'){let m=0;const picks=[];team.forEach(p=>{let h;if(pk[p.id]==='x'){h=pickOf(byRole(p.role));m+=rnd(-2,3)}else{h=HB[pk[p.id]];m+=3}picks.push([p.name,h.n]);const e=ep.find(x=>x.p.role===p.role);if(e){m+=ban!==null&&ep[ban]===e?1.5:cnt(h,e.h)*1.2}});closeOv();return res({mod:(m-12)*.4,picks})}
  draw()};draw()})}
function askTactic(w,l,n){return new Promise(res=>{ov(`<h3>Счёт ${w}:${l} · BO${n}</h3><div class="sub">Тактика на следующую карту:</div>${[['balanced','🧠 Сбалансированная'],['aggressive','⚡ Агрессия (ранний лид)'],['farm','🌾 Через фарм (поздняя игра)'],['teamfight','💥 Командные драки']].map(x=>`<button class="wide" data-a="t" data-v="${x[0]}">${x[1]}</button>`).join('')}`);act=d=>{closeOv();res(d.v)}})}
// ---- map sim with networth curve
function mapSim(my,opp,tac){const pw=Math.max(.1,Math.min(.9,.5+(my-opp)/70)),win=Math.random()<pw,dur=Math.round(rnd(24,46)),fin=(win?1:-1)*rnd(3000,16000),g={aggressive:.7,farm:1.5}[tac]||1,nw=[0];
 for(let t=1;t<=dur;t++)nw.push(Math.round(fin*Math.pow(t/dur,g)+(t<dur?Math.sin(t*1.7+rnd(0,2))*rnd(300,1500):0)));
 const kw=Math.round(rnd(22,42)),kl=Math.round(kw*rnd(.45,.85)),mvp=active().slice().sort((a,b)=>eff(b)*Math.random()-eff(a)*Math.random())[0];return{win,dur,nw,tac,kills:win?[kw,kl]:[kl,kw],mvp}}
const graph=(nw,c='#47d5e8')=>{const M=Math.max(...nw.map(Math.abs),1),d=nw.length-1||1;return`<svg viewBox="0 0 300 80" style="width:100%;height:80px;background:#0e1626;border-radius:8px"><line x1="0" y1="40" x2="300" y2="40" stroke="#334"/><polyline fill="none" stroke="${c}" stroke-width="2" points="${nw.map((v,t)=>(t/d*300).toFixed(1)+','+(40-v/M*36).toFixed(1)).join(' ')}"/></svg>`};
const TN={balanced:'сбаланс.',aggressive:'агрессия',farm:'фарм',teamfight:'драки'};
async function runSeries(n,eid){
 const d=await draft(eid);window.DRAFT=d.mod;let tac=$('tactic').value,w=0,l=0,maps=[],need=Math.ceil(n/2),opp=strength(eid)+11+SET.diff+rnd(-4,4),my=0;
 while(w<need&&l<need){my=DM.myPower(tac);const m=mapSim(my,opp,tac);m.n=maps.length+1;maps.push(m);m.win?w++:l++;if(w<need&&l<need)tac=await askTactic(w,l,n)}
 window.DRAFT=0;return{w,l,maps,won:w>l,opp,my,d}}
// ---- league
const byReg={};WORLD_ORGS.forEach(o=>(byReg[o.region]=byReg[o.region]||[]).push('world_'+o.id));
const row=id=>s.lg[id]||(s.lg[id]={w:0,l:0}),reg=id=>(orgOf(id)||{}).region,feed=m=>{s.feed.unshift(`С${s.season} Н${s.week}: ${m}`);s.feed.length=Math.min(s.feed.length,40)};
const table=()=>(byReg[reg(s.clubId)]||[]).map(id=>({id,...row(id)})).sort((a,b)=>b.w-a.w||a.l-b.l);
function aiRound(){Object.values(byReg).forEach(ids=>{const a=ids.filter(i=>i!==s.clubId&&rosterData[i]).sort(()=>Math.random()-.5);for(let i=0;i+1<a.length;i+=2){const p=1/(1+Math.exp(-(strength(a[i])-strength(a[i+1]))/6));Math.random()<p?(row(a[i]).w++,row(a[i+1]).l++):(row(a[i+1]).w++,row(a[i]).l++)}})}
// ---- play
let busy=false;
$('play').onclick=async()=>{
 if(busy)return;if(active().length!==5)return say('Для матча нужны 5 игроков в основном составе.',true);if(s.playedWeek)return say('На этой неделе матч уже сыгран. Заверши неделю.',true);
 busy=true;try{const n=+$('bo').value||1,mates=Object.keys(rosterData).filter(i=>i!==s.clubId&&reg(i)===reg(s.clubId)),all=Object.keys(rosterData).filter(i=>i!==s.clubId),id=pickOf(mates.length?mates:all),c=rosterData[id],tier=(orgOf(id)||{}).tier||2,r=await runSeries(n,id);
 const mult=(n===1?1:n===3?1.6:2.2)*(tier===1?1.3:tier===3?.8:1),prize=r.won?Math.round(22000*mult):0;
 s.report=`<div class="log"><b>${r.won?'🏆 ПОБЕДА':'❌ ПОРАЖЕНИЕ'} ${r.w}:${r.l} · ${rosterData[s.clubId].name} vs ${c.name} (BO${n})</b></div><div class="log muted">Драфт: ${r.d.picks.map(x=>x[0]+' — '+x[1]).join(', ')} (${r.d.mod>=0?'+':''}${r.d.mod.toFixed(1)})</div>`+r.maps.map(m=>`<div class="log"><b>Карта ${m.n}: ${m.win?'🏆':'❌'}</b> · ${m.dur} мин · ${m.kills[0]}:${m.kills[1]} · тактика: ${TN[m.tac]} · MVP ${m.mvp.name}</div>${graph(m.nw,m.win?'#55d99a':'#ff7185')}`).join('')+`<div class="row"><span>Сила соперника</span><b>${r.opp.toFixed(1)}</b></div>`;
 if(r.won){s.w++;s.rating+=18+(tier===1?14:tier===3?-4:6);s.money+=prize;s.synergy=Math.min(100,s.synergy+3)}else{s.l++;s.rating=Math.max(500,s.rating-(tier===3?24:12));s.synergy=Math.max(10,s.synergy-1)}
 if(reg(id)===reg(s.clubId))r.won?(row(s.clubId).w++,row(id).l++):(row(s.clubId).l++,row(id).w++);
 active().forEach(p=>{p.form=Math.max(20,Math.min(80,(p.form==null?50:p.form)+(r.won?4:-4)));p.fat=Math.min(100,(p.fat||0)+(trait(p)==='Трудяга'?4:8)*(n===1?1:n===3?1.4:1.8));
  if(Math.random()<((.03+(p.fat>70?.04:0))*(trait(p)==='Хрупкий'?2:1))){p.inj=1+Math.floor(rnd(0,4));feed(`🤕 ${p.name} получил травму на ${p.inj} нед.`);}});
 s.playedWeek=true;s.history.push(`Неделя ${s.week}: ${r.won?'🏆':'❌'} ${r.w}:${r.l} vs ${c.name}`);feed(`${r.won?'Победа':'Поражение'} ${r.w}:${r.l} vs ${c.name}`);s.news=r.won?'Победа над '+c.name+'!':'Поражение от '+c.name+'.';
 sfx(r.won?'win':'lose');render();say(r.won?'Победа! +'+fmt(prize):'Поражение.')}finally{busy=false}
};
// ---- weekly hooks
const _adv=$('advance').onclick;
function offerTick(){s.offers=s.offers.filter(o=>o.exp>=s.week&&s.players.some(p=>p.id===o.id));
 if(s.players.length>5&&Math.random()<.14){const p=pickOf(s.players),cl=pickOf(Object.keys(rosterData).filter(i=>i!==s.clubId));if(!s.offers.some(o=>o.id===p.id)){s.offers.push({id:p.id,club:cl,amt:Math.round(p.price*rnd(1,1.5)),exp:s.week+2});feed(`📨 ${rosterData[cl].name} предлагает ${fmt(s.offers.at(-1).amt)} за ${p.name}`)}}}
function seasonHook(){const rk=table().findIndex(x=>x.id===s.clubId)+1,ok=rk>0&&rk<=s.goal;
 if(ok){s.money+=60000;s.rating+=20}else s.rating=Math.max(500,s.rating-15);feed(`Итог сезона: ${rk} место. Цель (top ${s.goal}) ${ok?'выполнена, бонус 60 000':'провалена, рейтинг −15'}.`);s.lg={};const t=(orgOf(s.clubId)||{}).tier||2;s.goal={1:3,2:6,3:10}[t]}
$('advance').onclick=()=>{const sn=s.season;_adv();if(!s.clubId)return;aiRound();s.players.forEach(p=>{p.fat=Math.max(0,(p.fat||0)-12);if(p.inj>0)p.inj--;p.form=(p.form==null?50:p.form)+(p.form>50?-2:p.form<50?2:0)});offerTick();s.mh.push(s.money);if(s.mh.length>60)s.mh.shift();if(s.season>sn)seasonHook();render()};
const _start=startClub;startClub=function(id){_start(id);const t=(orgOf(id)||{}).tier||2;s.goal={1:3,2:6,3:10}[t];s.lg={};s.feed=[];s.offers=[];s.mh=[s.money];s.players.forEach(p=>{p.form=50;p.fat=0;p.inj=0});feed('Начало карьеры. Цель совета: top '+s.goal+' в лиге региона.');render()};
function mig(x){x.v=4;x.lg=x.lg||{};x.feed=x.feed||[];x.offers=x.offers||[];x.mh=x.mh||[x.money];x.goal=x.goal||6;return x}
const _f=fresh;fresh=function(){return mig(_f())};
// ---- profiles
const anyP=id=>s.players.find(p=>p.id===id)||s.pool.find(p=>p.id===id)||s.generatedPlayers.find(p=>p.id===id)||Object.values(rosterData).flatMap(c=>c.players).find(p=>p.id===id);
document.addEventListener('click',e=>{const b=e.target.closest('[data-prof]');if(!b||e.target.closest('#ov'))return;const p=anyP(b.dataset.prof);if(!p)return;const o=p.orgId?orgOf('world_'+p.orgId):null;
 ov(`<div class="club">${p.portrait?`<img src="${p.portrait}" width="72" height="72" style="border-radius:12px">`:'🎮'}<div><h3 style="margin:0">${p.name}</h3><div class="sub">${p.role} · ${p.age||'?'} лет${o?' · '+o.name:''}</div><div class="sub">Стиль: ${p.style||'универсал'} · черта: <b>${trait(p)}</b></div></div></div><div class="row"><span>Рейтинг / потенциал</span><b>${p.skill} / ${p.potential}</b></div><div class="row"><span>Форма / усталость</span><b>${Math.round(p.form==null?50:p.form)} / ${Math.round(p.fat||0)}</b></div><div class="row"><span>Травма</span><b>${p.inj?p.inj+' нед.':'нет'}</b></div><div class="row"><span>Зарплата · цена</span><b>${fmt(p.salary)} · ${fmt(p.price)}</b></div><b class="sub">Пул героев:</b><div class="fl">${pool(p).map(h=>`<span class="pill">${himg(h)} ${h.n}</span>`).join('')}</div><button class="wide" data-a="x">Закрыть</button>`);act=closeOv});
// ---- pages
const main=document.querySelector('nav').parentNode,nav=document.querySelector('nav'),foot=document.querySelector('.footer');
[['leaguePage','🏅 Лига'],['finPage','💰 Финансы'],['optPage','⚙️ Опции']].forEach(x=>{nav.insertAdjacentHTML('beforeend',`<button data-page="${x[0]}">${x[1]}</button>`);nav.lastChild.onclick=()=>go(x[0])});
document.querySelector('#notice').insertAdjacentHTML('beforebegin',`<section id="leaguePage" class="page"><h2>🏅 Лига региона</h2><div class="card"><div class="row"><b id="lgName">—</b><span class="tag" id="lgGoal"></span></div><div id="lgTable"></div></div><div class="card" style="margin-top:9px"><b>📰 Новости</b><div id="feedList" class="sub"></div></div></section>
<section id="finPage" class="page"><h2>💰 Финансы</h2><div class="card"><div class="row"><span>Баланс</span><b id="fBal"></b></div><div class="row"><span>Долг</span><b id="fDebt"></b></div><div class="row"><span>Доход − зарплаты / нед.</span><b id="fNet"></b></div><div id="fChart"></div></div><div class="card" style="margin-top:9px"><b>📨 Предложения клубов</b><div id="offers"></div></div></section>
<section id="optPage" class="page"><h2>⚙️ Опции</h2><div class="card"><button class="wide" id="oSnd"></button><label class="sub">Сложность</label><select id="oDiff" class="wide"><option value="-3">Лёгкая</option><option value="0">Нормальная</option><option value="3">Сложная</option></select></div><div class="card" style="margin-top:9px"><b>💾 Слоты сохранения</b><div id="slots"></div></div><div class="card" style="margin-top:9px"><b>📤 Экспорт / импорт</b><textarea id="xfer" class="wide" rows="3" placeholder="Код сохранения"></textarea><button class="wide" id="exp">Экспорт</button><button class="wide" id="imp">Импорт</button></div></section>`);
$('oDiff').value=SET.diff;$('oDiff').onchange=()=>{SET.diff=+$('oDiff').value;window.DIFF=SET.diff;saveSet()};
$('oSnd').onclick=()=>{SET.snd=!SET.snd;saveSet();music(cur);render()};
$('exp').onclick=()=>{persist();$('xfer').value=btoa(unescape(encodeURIComponent(localStorage.getItem(DM_KEY)||'')));say('Код сохранения создан — скопируй его.')};
$('imp').onclick=()=>{try{const t=decodeURIComponent(escape(atob($('xfer').value.trim()))),o=JSON.parse(t);if(!Array.isArray(o.players))throw 0;localStorage.setItem(DM_KEY,t);location.reload()}catch(e){say('Неверный код сохранения.',true)}};
const slotKey=n=>n==='1'?'dm26-update-0.2-save':'dm26-save-slot'+n,curSlot=()=>localStorage.getItem('dm26-slot')||'1';
$('slots').onclick=e=>{const b=e.target.closest('[data-slot]');if(!b)return;persist();localStorage.setItem('dm26-slot',b.dataset.slot);location.reload()};
const _r=render;render=function(){_r();
 $('oSnd').textContent=SET.snd?'🔊 Звук включён':'🔇 Звук выключен';
 $('slots').innerHTML=['1','2','3'].map(n=>{let t='пусто';try{const o=JSON.parse(localStorage.getItem(slotKey(n)));if(o&&o.clubId)t=(rosterData[o.clubId]?.name||'клуб')+' · сезон '+o.season}catch(e){}return`<button class="wide ${n===curSlot()?'primary':''}" data-slot="${n}">Слот ${n}: ${t}${n===curSlot()?' (активен)':''}</button>`}).join('');
 if(!s.clubId)return;
 document.querySelectorAll('#lineup [data-prof],#bench [data-prof]').forEach(b=>{const p=anyP(b.dataset.prof);if(p&&p.inj)b.insertAdjacentHTML('afterend',` <span class="pill" style="background:#7a2030">🤕 ${p.inj} нед.</span>`)});
 const tb=table(),rk=tb.findIndex(x=>x.id===s.clubId)+1;$('lgName').textContent='Лига: '+reg(s.clubId);$('lgGoal').textContent='Цель: top '+s.goal+' · сейчас '+rk;
 $('lgTable').innerHTML=tb.map((x,i)=>`<div class="row" style="${x.id===s.clubId?'color:var(--gold);font-weight:700':''}"><span>${i+1}. ${rosterData[x.id]?.name||x.id}</span><b>${x.w}–${x.l}</b></div>`).join('');
 $('feedList').innerHTML=s.feed.map(x=>`<div class="log">${x}</div>`).join('')||'Пока тихо.';
 $('fBal').textContent=fmt(s.money);$('fDebt').textContent=s.debt>0?fmt(s.debt):'нет';$('fNet').textContent=fmt(income()-wages());$('fChart').innerHTML=graph(s.mh.map(v=>v-s.mh[0]),'#ffc85a')+'<div class="sub">Динамика бюджета (по неделям)</div>';
 $('offers').innerHTML=s.offers.map((o,i)=>{const p=s.players.find(x=>x.id===o.id);return p?`<div class="row"><span>${rosterData[o.club].name} → ${p.name}: <b class="gold">${fmt(o.amt)}</b></span><span><button class="smallbtn" data-of="${i}|1">Принять</button> <button class="smallbtn" data-of="${i}|0">Нет</button></span></div>`:''}).join('')||'<div class="sub">Предложений нет.</div>'};
$('offers').onclick=e=>{const b=e.target.closest('[data-of]');if(!b)return;const[i,ok]=b.dataset.of.split('|'),o=s.offers[+i];if(!o)return;s.offers.splice(+i,1);
 if(ok==='1'){const p=s.players.find(x=>x.id===o.id);if(p&&s.players.length>5){s.money+=o.amt;s.players=s.players.filter(x=>x.id!==o.id);s.taken.push(o.id);rosterData[o.club].players.push({...p,active:false});s.fills.push({c:o.club,p:{...p,active:false}});DM.fixLineup();feed(`${p.name} продан в ${rosterData[o.club].name} за ${fmt(o.amt)}`)}else say('В клубе должно остаться минимум 5 игроков.',true)}render()};
// ---- tutorial
function tutorial(){if(localStorage.getItem('dm26-tut'))return;const T=['👋 Добро пожаловать! Выбери клуб: его уровень (tier) определяет бюджет и цель сезона.','🎯 Матч начинается с драфта: бань героя и выбирай героев из пула игроков — комфорт и контрпики дают бонус.','🏆 Раз в месяц на 4-й неделе — турнир. Следи за формой, усталостью и травмами игроков.','💰 Подписывай спонсоров, продавай лишних и отвечай на предложения клубов. Удачи!'];let i=0;const show=()=>{ov(`<div>${T[i]}</div><button class="wide primary" data-a="n">${i<T.length-1?'Далее':'Играть!'}</button>`);act=()=>{if(++i<T.length)show();else{closeOv();try{localStorage.setItem('dm26-tut','1')}catch(e){}}}};show()}
s=mig(s);s.players.forEach(p=>{if(p.form==null){p.form=50;p.fat=0;p.inj=0}});
document.querySelector('.footer').textContent='DOTA MANAGER 2026 · FAN-MADE · VERSION 0.4.0 · FINAL WEBVIEW';
render();if(!s.clubId)tutorial();
})();
