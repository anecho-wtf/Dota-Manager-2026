
/* ===== UPDATE 0.3 ===== */
(function(){
const KEY=DM_KEY;
const HEROES={Carry:['Phantom Lancer','Faceless Void','Medusa','Luna','Spectre','Terrorblade'],Mid:['Invoker','Storm Spirit','Puck','Queen of Pain','Tinker','Sniper'],Offlane:['Mars','Tidehunter','Centaur','Axe','Underlord','Beastmaster'],Support:['Earth Spirit','Tusk','Rubick','Mirana','Hoodwink','Dark Willow'],'Hard Support':['Crystal Maiden','Lion','Io','Shadow Shaman','Winter Wyvern','Warlock']};
const REQ={Major:1250,LAN:1150,League:0,Qualifier:0,'World Championship':1350,Finals:1300};
const rnd=(a,b)=>a+Math.random()*(b-a),pickOf=a=>a[Math.floor(Math.random()*a.length)];
const orgOf=id=>WORLD_ORGS.find(o=>'world_'+o.id===id);
const crestHtml=id=>`<img src="crests/${String(id).replace('world_','')}.png" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
const face=(p,z)=>p.portrait?`<img src="${p.portrait}" loading="lazy" alt="" style="width:${z}px;height:${z}px;border-radius:10px;object-fit:cover">`:`<div class="avatar">${p.emoji||'🎮'}</div>`;
freeAgents.length=0;

function migrate(x){x.taken=x.taken||[];x.pool=x.pool||[];x.delta=x.delta||{};x.fills=x.fills||[];x.debt=Number(x.debt)||0;x.tour=x.tour||{};x.players.forEach(p=>{if(p.contract==null)p.contract=2});return x}
const _fresh=fresh;fresh=function(){return migrate(_fresh())};
function applyWorld(){
 const gone=new Set([...s.taken,...s.players.map(p=>p.id),...s.pool.map(p=>p.id)]);
 for(const[id,c]of Object.entries(rosterData)){
  if(id===s.clubId){c.players=[];continue}
  c.players=c.players.filter(p=>!gone.has(p.id));c.players.forEach(p=>{const d=s.delta[p.id];if(d)Object.assign(p,d)});
 }
 s.fills.forEach(f=>{const c=rosterData[f.c];if(c&&!c.players.some(p=>p.id===f.p.id))c.players.push({...f.p})});
}
function strength(id){const c=rosterData[id];if(!c)return 60;let t=0;roles.forEach(r=>{const b=c.players.filter(p=>p.role===r).sort((a,b)=>b.skill-a.skill)[0];t+=b?b.skill:55});const o=orgOf(id);return t/5+(o?(o.reputation-60)*.08:0)}
function myPower(tac){const team=active(),cover=new Set(team.map(p=>p.role)).size;return team.reduce((a,p)=>a+(window.eff?eff(p):p.skill),0)/5+(window.DRAFT||0)+s.synergy*.2+({balanced:2,aggressive:4,farm:1,teamfight:3}[tac]||2)+(s.coach?3:0)+(s.base?2:0)-(5-cover)*4-(s.debt>0?3:0)}
function playMap(my,opp){
 const draft=Math.round(rnd(-3,3)+(s.coach?2:0)),pw=Math.max(.1,Math.min(.9,.5+(my+draft-opp)/70)),win=Math.random()<pw,team=active();
 const kw=Math.round(rnd(22,42)),kl=Math.round(kw*rnd(.45,.85)),mvp=team.slice().sort((a,b)=>b.skill*Math.random()-a.skill*Math.random())[0];
 return{win,draft,dur:Math.round(rnd(24,48)),kills:win?[kw,kl]:[kl,kw],mvp,roshan:Math.random()<.5,pick:team.map(p=>[p.name,pickOf(HEROES[p.role]||['Hero'])])};
}
function series(n,eid,tac){const need=Math.ceil(n/2),my=myPower(tac),opp=strength(eid)+11+(window.DIFF||0)+rnd(-4,4);let w=0,l=0,maps=[];while(w<need&&l<need){const m=playMap(my,opp);m.n=maps.length+1;maps.push(m);m.win?w++:l++}return{w,l,maps,won:w>l,my,opp}}
const mapHtml=m=>`<div class="log"><b>Карта ${m.n}: ${m.win?'🏆 победа':'❌ поражение'}</b> · ${m.dur} мин · убийства ${m.kills[0]}:${m.kills[1]}<br><span class="muted">${m.draft>1?'Драфт удался. ':m.draft<-1?'Драфт провален. ':'Драфт равный. '}${m.pick.map(x=>x[0]+' — '+x[1]).join(', ')}. ${m.roshan?'Рошан решил исход драки.':'Рошан не повлиял.'} MVP: ${m.mvp.name}</span></div>`;

$('play').onclick=()=>{
 if(active().length!==5)return say('Для матча нужны 5 игроков в основном составе.',true);
 if(s.playedWeek)return say('На этой неделе матч уже сыгран. Заверши неделю.',true);
 const n=+$('bo').value||1,ids=Object.keys(rosterData).filter(id=>id!==s.clubId),id=pickOf(ids),c=rosterData[id],tier=(orgOf(id)||{}).tier||2,r=series(n,id,$('tactic').value);
 const mult=(n===1?1:n===3?1.6:2.2)*(tier===1?1.3:tier===3?.8:1),prize=r.won?Math.round(22000*mult):0,cover=new Set(active().map(p=>p.role)).size;
 s.report=`<div class="log"><b>${r.won?'🏆 ПОБЕДА':'❌ ПОРАЖЕНИЕ'} ${r.w}:${r.l} · ${rosterData[s.clubId].name} vs ${c.name} (BO${n})</b></div>`+(cover<5?'<div class="log">⚠️ В основе не все роли — штраф к силе.</div>':'')+r.maps.map(mapHtml).join('')+`<div class="row"><span>Твоя сила</span><b>${r.my.toFixed(1)}</b></div><div class="row"><span>Сила ${c.name}</span><b>${r.opp.toFixed(1)}</b></div>`;
 if(r.won){s.w++;s.rating+=18+(tier===1?14:tier===3?-4:6);s.money+=prize;s.synergy=Math.min(100,s.synergy+3)}else{s.l++;s.rating=Math.max(500,s.rating-(tier===3?24:12));s.synergy=Math.max(10,s.synergy-1)}
 s.playedWeek=true;s.history.push(`Неделя ${s.week}: ${r.won?'🏆':'❌'} ${r.w}:${r.l} vs ${c.name}`);s.news=r.won?'Победа над '+c.name+'! Призовые зачислены.':'Поражение от '+c.name+'. Время готовиться к реваншу.';
 render();say(r.won?'Победа! +'+fmt(prize)+' призовых.':'Поражение. Проанализируй матч.');
};

function tourState(){
 const m=Math.floor((s.week-1)/4),t=tournamentPlan[m],key=s.season+'-'+m,wk=(s.week-1)%4+1,type=t[2],qual=type==='World Championship'&&s.tour['q'+s.season];let msg,ok=false;
 if(s.tour[key])msg=`${t[1]} уже сыгран в этом сезоне.`;
 else if(wk<4)msg=`${t[1]} · ${type} · фонд ${fmt(t[3])} 🪙. Турнир проходит на 4-й неделе месяца (сейчас ${wk}-я).`;
 else if(s.rating<REQ[type]&&!qual)msg=`${t[1]}: нужен рейтинг ${REQ[type]}${type==='World Championship'?' или победа/финал в квалификации':''}. У тебя ${fmt(s.rating)}.`;
 else if(s.playedWeek)msg='На этой неделе уже был матч.';
 else{msg=`${t[1]} · ${type} · фонд ${fmt(t[3])} 🪙 · 8 команд, плей-офф BO3, финал BO5.`;ok=true}
 return{t,key,msg,ok};
}
$('playTour').onclick=()=>{
 const st=tourState();if(!st.ok)return say(st.msg,true);if(active().length!==5)return say('Для матча нужны 5 игроков в основном составе.',true);
 const t=st.t,type=t[2],tac=$('tactic').value,all=Object.keys(rosterData).filter(id=>id!==s.clubId).sort((a,b)=>strength(b)-strength(a)),
  lim={Major:24,LAN:50,'World Championship':16,Finals:24}[type]||all.length,opp=all.slice(0,lim).sort(()=>Math.random()-.5).slice(0,3),
  names=['Четвертьфинал','Полуфинал','Финал'],fm=[3,3,type==='League'||type==='Qualifier'?3:5];let place=1,html=`<div class="log"><b>🏟️ ${t[1]} (${type})</b></div>`;
 for(let i=0;i<3;i++){const r=series(fm[i],opp[i],tac);html+=`<div class="log"><b>${names[i]}</b> vs ${rosterData[opp[i]].name} · BO${fm[i]} · ${r.w}:${r.l} ${r.won?'🏆':'❌'}</div>`;if(!r.won){place=[5,3,2][i];break}}
 const share={1:.45,2:.25,3:.12,5:.05}[place],prize=Math.round(t[3]*share),rp={1:60,2:40,3:25,5:10}[place];
 s.money+=prize;s.rating+=rp;s.tour[st.key]=place;if(type==='Qualifier'&&place<=3)s.tour['q'+s.season]=1;s.playedWeek=true;
 s.synergy=Math.max(10,Math.min(100,s.synergy+(place<=2?5:-2)));
 const pl={1:'🥇 1 место',2:'🥈 2 место',3:'🥉 3–4 место',5:'5–8 место'}[place];
 s.report=html+`<div class="row"><b>${pl}</b><b class="gold">+${fmt(prize)} 🪙 · +${rp} рейтинга</b></div>`+(type==='Qualifier'&&place<=3?'<div class="log">✅ Путёвка на The International получена!</div>':'');
 s.history.push(`Неделя ${s.week}: ${t[1]} — ${pl}`);s.news=`${t[1]}: ${pl}.`;render();say(`${t[1]}: ${pl}, +${fmt(prize)}`);
};

function sell(id){
 const p=s.players.find(x=>x.id===id);if(!p)return;if(s.players.length<=5)return say('В клубе должно остаться минимум 5 игроков.',true);
 const refund=Math.round(p.price*.5);if(!confirm(`Продать ${p.name} за ${fmt(refund)}?`))return;
 s.money+=refund;s.players=s.players.filter(x=>x.id!==id);s.pool.push({...p,active:false,owner:'free'});fixLineup();s.synergy=Math.max(20,s.synergy-3);render();say(p.name+' продан. +'+fmt(refund));
}
function fixLineup(){roles.forEach(r=>{if(!active().some(p=>p.role===r)){const b=bench().filter(p=>p.role===r).sort((a,b)=>b.skill-a.skill)[0];if(b)b.active=true}})}
document.addEventListener('click',e=>{const b=e.target.closest('[data-sell]');if(b)sell(b.dataset.sell)});
playerRow=function(p,b){return `<div class="player">${face(p,36)}<div><b data-prof="${p.id}" style="cursor:pointer">${p.name}</b> <span class="pill">${p.role}</span><div class="sub">${p.skill} OVR · пот. ${p.potential}${p.age?' · '+p.age+' л.':''} · контракт ${p.contract==null?2:p.contract} сез.</div><div class="bar"><i style="width:${p.skill}%"></i></div></div><div style="display:flex;flex-direction:column;gap:4px">${b?`<button class="smallbtn" data-promote="${p.id}">В основу</button>`:`<span class="tag">ОСНОВА</span>`}<button class="smallbtn" data-sell="${p.id}">Продать</button></div></div>`};

function findP(id){for(const[cid,c]of Object.entries(rosterData)){if(cid===s.clubId)continue;const p=c.players.find(x=>x.id===id);if(p)return{p,src:cid}}let p=s.pool.find(x=>x.id===id);if(p)return{p,src:'pool'};p=s.generatedPlayers.find(x=>x.id===id);return p?{p,src:'gen'}:null}
buy=function(id){
 const f=findP(id);if(!f)return say('Игрок уже недоступен.',true);const p=f.p;
 if(s.players.length>=12)return say('Состав заполнен: максимум 12 игроков.',true);if(s.money<p.price)return say('Не хватает денег на трансфер.',true);
 s.money-=p.price;let from='свободных агентов';
 if(f.src==='pool')s.pool=s.pool.filter(x=>x.id!==id);else if(f.src==='gen'){s.generatedPlayers=s.generatedPlayers.filter(x=>x.id!==id);from='академии'}
 else{const c=rosterData[f.src];from=c.name;c.players=c.players.filter(x=>x.id!==id);s.taken.push(id);
  const g=generatedPlayer('ai-'+Date.now().toString(36)+Math.floor(Math.random()*999),roles.indexOf(p.role));g.role=p.role;g.skill=Math.min(g.skill,Math.max(60,p.skill-6));g.potential=Math.max(g.skill,g.potential);g.age=19+Math.floor(Math.random()*8);c.players.push(g);s.fills.push({c:f.src,p:g})}
 s.players.push({...p,active:!active().some(x=>x.role===p.role)&&active().length<5,owner:s.clubId,contract:2});
 s.synergy=Math.max(20,s.synergy-3);s.news=p.name+' перешёл из '+from+' в '+rosterData[s.clubId].name+'.';render();say('Трансфер завершён! '+p.name+' теперь в клубе.');
};
renderMarket=function(){
 const f=document.querySelector('[data-filter].active')?.dataset.filter||'all',q=($('marketSearch')?.value||'').toLowerCase().trim(),have=new Set(s.players.map(p=>p.id));let list=[];
 Object.entries(rosterData).forEach(([id,c])=>{if(id!==s.clubId)c.players.forEach(p=>list.push({...p,ownerName:c.name,free:0}))});
 s.pool.concat(s.generatedPlayers).forEach(p=>list.push({...p,ownerName:'Свободный агент',free:1}));
 list=list.filter(p=>!have.has(p.id));if(f==='clubs')list=list.filter(p=>!p.free);if(f==='free')list=list.filter(p=>p.free);
 if(q)list=list.filter(p=>(p.name+' '+p.role+' '+p.ownerName+' '+(p.region||'')).toLowerCase().includes(q));
 list.sort((a,b)=>b.skill-a.skill);$('marketCount').textContent='Найдено игроков: '+list.length+' · первые 60 по рейтингу';
 $('marketList').innerHTML=list.slice(0,60).map(p=>`<div class="card" style="margin-bottom:8px"><div class="row"><div class="club">${face(p,40)}<div><b data-prof="${p.id}" style="cursor:pointer">${p.name}</b><div class="sub">${p.role} · ${p.ownerName}${p.age?' · '+p.age+' л.':''}</div></div></div><span class="tag">${p.skill} OVR</span></div><div class="row"><span class="sub">💰 Трансфер · потенциал ${p.potential}</span><b class="gold">${fmt(p.price)}</b></div><div class="row"><span class="sub">Зарплата / нед.</span><b>${fmt(p.salary)}</b></div><button class="wide primary" data-buy="${p.id}" ${s.players.length>=12||s.money<p.price?'disabled':''}>Купить игрока</button></div>`).join('')||'<div class="empty">Игроков по этому фильтру нет.</div>';
 $('marketList').querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buy(b.dataset.buy));
};

const _start=startClub;
startClub=function(id){
 _start(id);const o=orgOf(id),c=rosterData[id];s.money={1:500000,2:350000,3:220000}[o&&o.tier]||350000;s.taken=[];s.fills=[];s.pool=[];s.delta={};s.debt=0;s.tour={};
 const have=new Set(s.players.map(p=>p.id));c.players.filter(p=>!have.has(p.id)).slice(0,3).forEach(p=>s.players.push({...p,active:false,owner:id}));
 s.players.forEach(p=>{p.contract=1+Math.floor(Math.random()*3)});render();
};

function grow(p){p.age=(p.age||22)+1;if(p.age<=22)p.skill=Math.min(p.potential||99,p.skill+Math.floor(rnd(1,4)));else if(p.age>=30)p.skill=Math.max(50,p.skill-Math.floor(rnd(1,3)))}
function seasonEnd(){
 s.week=1;s.season++;s.rating+=Math.max(0,s.w*2-s.l);s.tour={['q'+s.season]:0};
 s.players.forEach(grow);let lost=[];
 s.players=s.players.filter(p=>{p.contract=(p.contract==null?2:p.contract)-1;if(p.contract>0)return true;const fee=p.salary*8;if(s.money>=fee){s.money-=fee;p.contract=2;return true}lost.push(p.name);s.pool.push({...p,active:false,owner:'free',price:Math.round(p.price*.6)});return false});
 fixLineup();
 Object.entries(rosterData).forEach(([id,c])=>{if(id!==s.clubId)c.players.forEach(p=>{grow(p);s.delta[p.id]={skill:p.skill,age:p.age}})});
 s.news=`Сезон завершён! Начался сезон №${s.season}. Игроки повзрослели.`+(lost.length?' Ушли из-за контрактов: '+lost.join(', ')+'.':'');
}
$('advance').onclick=()=>{
 let inc=income(),due=wages();
 if(s.debt>0){const pay=Math.min(s.debt,Math.max(0,inc));s.debt-=pay;inc-=pay;s.debt=Math.round(s.debt*1.03)}
 const avail=inc+s.money,paid=Math.min(avail,due),unpaid=due-paid;s.money=Math.max(0,avail-paid);
 if(unpaid>0){s.debt+=unpaid;s.synergy=Math.max(10,s.synergy-6)}
 if(s.debt>250000){say('Долг клуба превысил 250 000. Совет директоров расторг контракт. Начни новую карьеру.',true);try{localStorage.removeItem(KEY)}catch(e){}setTimeout(()=>location.reload(),2500);return}
 s.week++;s.playedWeek=false;
 if(s.week>48)seasonEnd();else s.news=unpaid>0?`⚠️ Не хватило ${fmt(unpaid)} на зарплаты — они ушли в долг (рост 3%/нед). Сыгранность упала.`:'Началась неделя '+s.week+'. Бюджет обновлён.';
 render();say(unpaid>0?'Долг: '+fmt(s.debt)+'. Подпиши спонсора!':'Неделя завершена. Зарплаты выплачены. Баланс: '+fmt(s.money),unpaid>0);
};
$('reset').onclick=()=>{if(confirm('Начать новую карьеру? Текущий прогресс будет удалён.')){try{localStorage.removeItem(KEY)}catch(e){}location.reload()}};

const _render=render;
render=function(){_render();
 if(!s.clubId){document.querySelectorAll('#clubChoices .card').forEach(card=>{const b=card.querySelector('[data-club]'),c=card.querySelector('.crest');if(b&&c)c.innerHTML=crestHtml(b.dataset.club)})}
 else{$('clubCrest').innerHTML=crestHtml(s.clubId);$('benchCount').textContent=bench().length+' / 7';
  const st=tourState();$('tourInfo').textContent=st.msg;$('playTour').disabled=!st.ok;
  $('news').textContent=s.news+(s.debt>0?' · 💸 Долг: '+fmt(s.debt):'');
  const o=orgOf(s.clubId);if(o)$('clubRosterPreview').textContent=`Tier ${o.tier} · ${o.region} · ${s.players.length} игроков · цель сезона: плей-офф`}
};
window.DM={series,myPower,strength,orgOf,rnd,pickOf,fixLineup,grow,REQ,tourState};window.dmBack=()=>{const cur=document.querySelector('.page.active')?.id;if(s.clubId&&cur&&cur!=='home'){go('home');return true}return false};
s=migrate(s);applyWorld();render();
})();
