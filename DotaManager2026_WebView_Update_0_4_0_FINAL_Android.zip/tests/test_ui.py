# Автотест Dota Manager 0.4 (Playwright + Chromium): python tests/test_ui.py
import os
from playwright.sync_api import sync_playwright
URL='file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','app/src/main/assets/index.html'))
errs=[]
def play(pg,n):
    pg.evaluate("go('events');s.playedWeek=false");pg.select_option('#bo',n);pg.click('#play');pg.click('[data-a=auto]');pg.click('[data-a=go]')
    for _ in range(6):
        if pg.locator('#ov:not([hidden]) [data-a=t]').count():pg.locator('[data-a=t]').first.click()
        pg.wait_for_timeout(80)
    return pg.evaluate("s.report.match(/(ПОБЕДА|ПОРАЖЕНИЕ) \\d:\\d/)[0]")
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':800})
    pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('dialog',lambda d:d.accept())
    pg.goto(URL);pg.wait_for_timeout(600);print('tutorial',pg.locator('#ov:not([hidden])').count())
    for _ in range(4):pg.click('[data-a=n]')
    pg.locator('[data-club="world_org001"]').click();pg.wait_for_timeout(200)
    print('goal',pg.evaluate('s.goal'),'players',pg.evaluate('s.players.length'))
    for n in('1','3','5'):print('BO'+n,play(pg,n),'maps svg',pg.locator('#report svg').count())
    print('league rows',pg.evaluate("document.querySelectorAll('#lgTable .row').length"),pg.inner_text('#lgGoal'))
    for _ in range(8):pg.evaluate("go('home')");pg.click('#advance')
    print('week',pg.evaluate('s.week'),'lg games',pg.evaluate("Object.values(s.lg).reduce((a,r)=>a+r.w,0)"),'mh',pg.evaluate('s.mh.length'),'offers',pg.evaluate('s.offers.length'))
    pg.evaluate("s.offers=[{id:s.players[7].id,club:Object.keys(rosterData)[5],amt:50000,exp:99}]");pg.evaluate("go('finPage')");pg.locator('[data-of]').first.click();print('sold',pg.evaluate('s.players.length'))
    pg.evaluate("go('squad')");pg.locator('[data-prof]').first.click();print('profile',pg.inner_text('#ov')[:60].replace('\n',' '));pg.click('#ov [data-a=x]')
    pg.evaluate("s.week=48");pg.evaluate("go('home')");pg.click('#advance');print('season',pg.evaluate('[s.season,s.week]'),pg.evaluate('s.feed[0]'))
    pg.evaluate("s.week=4;s.playedWeek=false;s.rating=1500;go('events')");pg.click('#playTour');print('tour',pg.evaluate('JSON.stringify(s.tour)'))
    pg.evaluate("go('optPage')");pg.click('#exp');code=pg.input_value('#xfer');print('export len',len(code))
    pg.click('[data-slot="2"]');pg.wait_for_timeout(500);print('slot2 empty clubId=',repr(pg.evaluate('s.clubId')))
    pg.evaluate("go('optPage')");pg.click('[data-slot="1"]');pg.wait_for_timeout(500);print('slot1 restored',pg.evaluate('[s.clubId,s.season]'))
    pg.set_viewport_size({'width':320,'height':700});print('overflow',pg.evaluate("document.documentElement.scrollWidth>innerWidth"))
    imgs=pg.evaluate("[...document.images].filter(i=>i.complete&&i.naturalWidth===0).length");print('broken imgs',imgs)
    b.close()
print('ERRORS',errs)
