DOTA MANAGER 2026 — UPDATE 0.3.0

CHANGES 0.3.0:
- Transfers and the whole world now persist after restart (bought players no longer reappear in old clubs; clubs get replacement players).
- Matches: opponent strength comes from the real roster; BO1/BO3/BO5 series, map-by-map reports with draft, heroes, MVP.
- Tournaments: monthly 8-team playoff (BO3, final BO5), rating requirements, prize money, TI qualifier.
- Economy: starting budget by club tier, contracts (renewal fee 8x salary), player growth/aging each season, wage debt with 3% interest and board dismissal at 250,000 debt.
- Squad: portraits and crests everywhere, bench of up to 7, selling players, 3 starting bench players.
- Android: Back button navigation, launcher icon. Version 0.3.0 (versionCode 8).
- Old save key kept: existing careers continue.

DOTA MANAGER 2026 — GLOBAL UPDATE 0.2
Android project · portrait orientation · offline assets

WHAT IS INCLUDED
- 120 organizations across 8 regions.
- 1,000 generated player profiles with roles, ratings, potential, age, salary, transfer price and play style.
- 1,000 original stylized player portrait PNGs and 120 original organization crests.
- Searchable world database and transfer market (first 80 matching results shown at once).
- Career roster: 5 starters plus 3–4 bench players; up to 12 squad slots.
- Fresh career storage key: dm26-update-0.2-save. Beta 0.1 / v3 / v4 saves are intentionally NOT imported.
- Offline operation: portraits and database are bundled in app assets.

IMPORTANT DATA NOTE
This is an esports management simulation. The 1,000 player identities and ratings are generated fictional game data. Some organization names are used as scenario labels; player affiliations, lineups, ratings and availability are simulated and are not verified current official rosters. No official affiliation is implied.

BUILD
Open this folder as a Gradle Android project in Android Studio, or use the repository's GitHub Actions Android build workflow if you add it to your repository. Build variant: app / assembleDebug.
Application ID: com.dotamanager2026
Version: 0.2 (versionCode 6)
Minimum Android: API 23


QA PATCH 0.2.1:
- Fixed missing WORLD_ORGS/WORLD_PLAYERS runtime database declarations (previous build crashed on startup).
- Balanced generated club rosters across all five Dota roles.
- Made all 1,000 generated player names unique.
- Fixed match opponent selection across all available organizations.
- Added malformed-save guards and roster-state validation.
- Added generated portrait rendering to team roster rows.
