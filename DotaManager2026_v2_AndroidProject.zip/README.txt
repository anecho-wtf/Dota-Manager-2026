DOTA MANAGER 2026 — Android project, version 2.0

Features:
- Mixed roster: fictional generated players plus a small set of publicly known Dota 2 player names.
- Transfer market with role slots, transfer prices and weekly salaries.
- Text-based match simulation with tactical style selection and match event report.
- Club finances, sponsor contract, coach, training, synergy, season progression.
- Local browser storage autosave in Android WebView.

Build APK:
1. Install Android Studio and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync; install Android SDK Platform 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK path: app/build/outputs/apk/debug/app-debug.apk

This archive is a source project, not a compiled APK. Android Studio is required to compile it.
